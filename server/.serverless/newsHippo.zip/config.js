module.exports = {
  aws: {
    region: 'us-east-1',
    accessKeyId: 'AKIAJ6BHT2VSJSHPVGBQ',
    secretAccessKey: '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'
  },
  haven: {
    token: '0c13604d-0aaf-42d6-ad91-7d7e8878714b'
  },
  rollbar: {
    token: '2397a55b1a02400381a280b4c5936413'
  }
};
